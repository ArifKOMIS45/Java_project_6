package Settings;

public class UserSettings {

    /*
    All variables public
    Strings are   username
                  password
                  Address1
                  City
                  ZipCode
                  ItemName
                  customText
                  color

    boolean       wanaCustomText
    double        myPrice

     */

    /*
   Bütün variables lar  public
   Stringler   username
                 password
                 Address1
                 City
                 ZipCode
                 ItemName
                 customText
                 color

   boolean       wanaCustomText
   double        myPrice

    */


    /*

     Create a toString method
         return all the variables like

                "\nusername : " + username +
                "\npassword :" + password +
                "\nAddress1 " + Address1+
                 ........

     */


    /*

         toString methodunu oluşturun
         Bütün variables ları aşağıdaki gibi return et

                "\nusername : " + username +
                "\npassword :" + password +
                "\nAddress1 " + Address1+
                 ........

     */

}
