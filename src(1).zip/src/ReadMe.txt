# Java Project 6
This project about incredible java

##### TODO:

1. Bu proje methodların hepsini yazmadan çalışmaz
2. Bu proje online alış-veriş sitesinden ürün satın alma ile ilgilidir.
3. İstediğinşz class dan başlayabilirsiniz. Önerimiz aşağıdaki  şekilde ilerlemeniz
    1. Settings package UserSettings 
    2. Item > usernameandpassword > address
4. Bütün açıklamalar classların içinde mevcuttur.

5. Testpaketi üzerinde çalışırken test sınıfınız mümkün olduğunca fazla test seçeneğini test etmeye çalışın
  1. Ekstra.Intervıew sorusu: Bir method oluşturun. 
bu methodu hangi girişlerle test edebileceğiniz (temel olarak bunun için bir test durumu oluşturun)